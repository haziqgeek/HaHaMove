package com.example.hahamove;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.time.LocalTime;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private Spinner spVehicle;
    private Switch swExtraStops;
    private EditText etExtraStops;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize spinner
        spVehicle = findViewById(R.id.spVehicle);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.vehicle, R.layout.spinner_item);
        spVehicle.setAdapter(adapter);

        // set listener to the Activity Factor switch
        swExtraStops = findViewById(R.id.swExtraStops);
        etExtraStops = findViewById(R.id.etExtraStops);
        swExtraStops.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {
                // if toggled on, enable, otherwise disable Activity level spinner
                if (checked) {
                    etExtraStops.setFocusableInTouchMode(true);
                    etExtraStops.setFocusable(true);
                    etExtraStops.setEnabled(true); // enable edit text
                }
                else {
                    etExtraStops.setEnabled(false); // disable this edittext
                    etExtraStops.setFocusable(false);
                    etExtraStops.setFocusableInTouchMode(false);
                }
            }
        });

        EditText etTime = findViewById(R.id.etTime);
        etTime.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {
                    Calendar calendar = Calendar.getInstance();
                    int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
                    int currentMinute = calendar.get(Calendar.MINUTE);

                    TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                            etTime.setText(String.format("%02d:%02d", hourOfDay, minutes));
                        }
                    }, currentHour, currentMinute, false);
                    timePickerDialog.show();
                }
            }
        });
    }
    public void calcDeliveryRate(View view) {
        // read inserted values
        // read vehicle
        int selectedVehicle =  spVehicle.getSelectedItemPosition();
        // read km
        EditText etKilometre = findViewById(R.id.etKilometre);
        int km = Integer.parseInt(etKilometre.getText().toString());

        double rate = 0;

        switch (selectedVehicle) {
            case 0:
                if (km > 0 && km <= 5)
                    rate = 5.0;
                else if (km <= 10)
                    rate = 5.0 + 1.0 * (km - 5);
                else
                    rate = 10.0 + 0.8 * (km - 10);
                break;
            case 1:
                if (km > 0 && km <= 5)
                    rate = 8.0;
                else if (km <= 15)
                    rate = 8.0 + 1.0 * (km - 5);
                else
                    rate = 18.0 + 1.5 * (km - 15);
                break;
            case 2:
                if (km > 0 && km <= 10)
                    rate = 22.0;
                else if (km <= 100)
                    rate = 22.0 + 2.2 * (km - 10);
                else
                    rate = 220.0 + 1.65 * (km - 100);
                break;
        }
        // check extra stops
        if (swExtraStops.isChecked()) {
            // read
            etExtraStops = findViewById(R.id.etExtraStops);
            int stops = Integer.parseInt(etExtraStops.getText().toString());
            switch (selectedVehicle) {
                case 0:
                    rate += 1.0 * stops;
                    break;
                case 1:
                    rate += 2.0 * stops;
                    break;
                case 2:
                    rate += 5.0 * stops;
                    break;
            }
        }
        DecimalFormat f = new DecimalFormat("##.00");

        // read time
        EditText etTime = findViewById(R.id.etTime);
        LocalTime time = LocalTime.parse(etTime.getText().toString());
        LocalTime startTime = LocalTime.parse("00:00");
        LocalTime endTime = LocalTime.parse("05:59");

        if (time.isAfter(startTime) && time.isBefore(endTime))
            rate = 1.3 * rate;

        // display result
        Toast.makeText(getApplicationContext(),"Delivery Rate: RM" + f.format(rate),Toast.LENGTH_SHORT).show();
        }
    }